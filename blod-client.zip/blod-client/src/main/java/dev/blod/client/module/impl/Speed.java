package dev.blod.client.module.impl;

import dev.blod.client.event.Subscribe;
import dev.blod.client.event.TickEvent;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.BoolSetting;
import dev.blod.client.module.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Faster ground / air movement (sets horizontal velocity directly) with optional bunny hop. */
public final class Speed extends Module {
    private final NumberSetting speed = add(new NumberSetting("Speed", 0.36, 0.1, 1.0, 0.01));
    private final BoolSetting hop = add(new BoolSetting("Bunny Hop", true));

    public Speed() {
        super("Speed", "Move faster.", Category.MOVEMENT, -1);
    }

    @Subscribe
    public void onTick(TickEvent e) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null || MoveUtil.inLiquidOrSpecial(p) || !MoveUtil.isMoving()) return;

        double[] d = MoveUtil.direction(p);
        Vec3d v = p.getVelocity();
        double y = v.y;
        if (hop.get() && p.isOnGround() && !mc.options.sneakKey.isPressed()) y = 0.42;
        p.setVelocity(d[0] * speed.get(), y, d[1] * speed.get());
    }
}
