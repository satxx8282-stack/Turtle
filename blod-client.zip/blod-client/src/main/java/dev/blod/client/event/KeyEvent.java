package dev.blod.client.event;

/** Raw keyboard event. action: 0 = release, 1 = press, 2 = repeat (GLFW values). */
public record KeyEvent(int key, int action) {}
