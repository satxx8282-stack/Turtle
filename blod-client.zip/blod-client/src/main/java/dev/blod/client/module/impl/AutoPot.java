package dev.blod.client.module.impl;

import dev.blod.client.event.Subscribe;
import dev.blod.client.event.TickEvent;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SplashPotionItem;
import net.minecraft.util.Hand;

/** Throws a splash healing potion at your feet when health is low. */
public final class AutoPot extends Module {
    private final NumberSetting health = add(new NumberSetting("Health", 12, 2, 19, 1));
    private final NumberSetting delay = add(new NumberSetting("Delay (ticks)", 10, 2, 40, 1));

    private int cooldown, restoreSlot = -1;

    public AutoPot() {
        super("AutoPot", "Throws healing potions when low on health.", Category.COMBAT, -1);
    }

    @Subscribe
    public void onTick(TickEvent e) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null || mc.currentScreen != null) return;

        if (restoreSlot != -1) { p.getInventory().selectedSlot = restoreSlot; restoreSlot = -1; }
        if (cooldown > 0) { cooldown--; return; }
        if (p.getHealth() > health.get()) return;

        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (!(s.getItem() instanceof SplashPotionItem) || !isHealing(s)) continue;

            int old = p.getInventory().selectedSlot;
            float oldPitch = p.getPitch();
            p.getInventory().selectedSlot = i;
            p.setPitch(90f);                                       // throw straight down
            mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
            p.setPitch(oldPitch);
            restoreSlot = old;
            cooldown = delay.getValue().intValue();
            return;
        }
    }

    private boolean isHealing(ItemStack s) {
        PotionContentsComponent c = s.get(DataComponentTypes.POTION_CONTENTS);
        if (c == null) return false;
        return c.potion().flatMap(entry -> entry.getKey()).map(k -> k.getValue().getPath().contains("healing")).orElse(false);
    }
}
