package dev.blod.client.module.impl;

import dev.blod.client.BlodClient;
import dev.blod.client.event.Render2DEvent;
import dev.blod.client.event.Subscribe;
import dev.blod.client.gui.Projection;
import dev.blod.client.gui.RenderUtil;
import dev.blod.client.gui.Theme;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.util.CombatTracker;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;

/** Two animated red rings that sweep up and down your current target (KillAura target or last entity you hit). */
public final class TargetESP extends Module {
    public TargetESP() {
        super("TargetESP", "Marks your current target.", Category.RENDER, -1);
    }

    @Subscribe
    public void onRender2D(Render2DEvent ev) {
        if (mc.player == null) return;
        KillAura ka = BlodClient.module(KillAura.class);
        LivingEntity t = ka != null && ka.isEnabled() && ka.getTarget() != null ? ka.getTarget() : CombatTracker.getLast();
        if (t == null) return;

        DrawContext ctx = ev.context();
        Vec3d feet = t.getLerpedPos(ev.tickDelta());
        double r = t.getWidth() * 0.85;
        double time = System.currentTimeMillis() / 900.0;

        for (int ring = 0; ring < 2; ring++) {
            double phase = 0.5 + 0.5 * Math.sin(time * Math.PI + ring * Math.PI);          // 0..1, rings in opposite phase
            double y = feet.y + t.getHeight() * phase;
            int color = Theme.alpha(Theme.lerp(Theme.RED, Theme.BRIGHT_RED, (float) phase), 235);

            double[] prev = null, first = null;
            int n = 24;
            for (int i = 0; i < n; i++) {
                double a = i * Math.PI * 2 / n;
                double[] p = Projection.project(new Vec3d(feet.x + Math.cos(a) * r, y, feet.z + Math.sin(a) * r), ev.tickDelta());
                if (prev != null && p != null) RenderUtil.line(ctx, prev[0], prev[1], p[0], p[1], color);
                if (i == 0) first = p;
                prev = p;
            }
            if (prev != null && first != null) RenderUtil.line(ctx, prev[0], prev[1], first[0], first[1], color);
        }
    }
}
