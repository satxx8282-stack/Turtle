package dev.blod.client.module.impl;

import dev.blod.client.event.Render2DEvent;
import dev.blod.client.event.Subscribe;
import dev.blod.client.gui.NotificationManager;
import dev.blod.client.gui.RenderUtil;
import dev.blod.client.gui.Theme;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/** Toast notifications (bottom-right) when modules are toggled. */
public final class NotificationsModule extends Module {
    private static final long LIFE = 2800, FADE_IN = 250, FADE_OUT = 350;

    public NotificationsModule() {
        super("Notifications", "Shows a toast when a module is toggled.", Category.CLIENT, -1);
        setListed(false);
    }

    @Subscribe
    public void onRender2D(Render2DEvent e) {
        DrawContext ctx = e.context();
        TextRenderer tr = mc.textRenderer;
        long now = System.currentTimeMillis();
        NotificationManager.LIST.removeIf(n -> now - n.created() > LIFE);

        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        int i = 0;
        for (var n : NotificationManager.LIST) {
            long age = now - n.created();
            float in = Theme.easeOutCubic(Math.min(1f, age / (float) FADE_IN));
            float out = age > LIFE - FADE_OUT ? (LIFE - age) / (float) FADE_OUT : 1f;
            int w = RenderUtil.width(tr, n.text()) + 22, h = 20;
            int x = (int) (sw - (w + 8) * in) + (int) ((1f - out) * 30);
            int y = sh - 52 - i * 24;
            float a = Math.max(0f, Math.min(1f, out));

            RenderUtil.roundedOutline(ctx, x, y, w, h, 4, Theme.mulAlpha(Theme.DARK_RED, a), Theme.mulAlpha(0xF00A0A0A, a));
            ctx.fill(x + 1, y + 4, x + 3, y + h - 4, Theme.mulAlpha(n.positive() ? Theme.RED : Theme.TEXT_DIM, a));
            RenderUtil.text(ctx, tr, n.text(), x + 10, y + 6, Theme.mulAlpha(Theme.TEXT, a), false);
            i++;
        }
    }
}
