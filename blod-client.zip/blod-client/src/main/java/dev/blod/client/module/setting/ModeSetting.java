package dev.blod.client.module.setting;

public final class ModeSetting extends Setting<String> {
    private final String[] modes;

    public ModeSetting(String name, String value, String... modes) {
        super(name, value);
        this.modes = modes;
    }

    public boolean is(String mode) { return getValue().equalsIgnoreCase(mode); }

    public void cycle(int dir) {
        int i = 0;
        for (int k = 0; k < modes.length; k++) if (modes[k].equals(getValue())) i = k;
        setValue(modes[Math.floorMod(i + dir, modes.length)]);
    }
}
