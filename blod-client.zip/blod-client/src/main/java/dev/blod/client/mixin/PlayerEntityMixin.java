package dev.blod.client.mixin;

import dev.blod.client.BlodClient;
import dev.blod.client.module.impl.Reach;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Reach: bigger entity interaction range for the local player. */
@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin {
    @Inject(method = "getEntityInteractionRange", at = @At("RETURN"), cancellable = true, require = 0)
    private void blod$reach(CallbackInfoReturnable<Double> cir) {
        if ((Object) this != MinecraftClient.getInstance().player) return;
        Reach r = BlodClient.module(Reach.class);
        if (r != null && r.isEnabled()) cir.setReturnValue(Math.max(cir.getReturnValueD(), r.range()));
    }
}
