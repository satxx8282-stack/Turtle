package dev.blod.client.module.impl;

import dev.blod.client.BlodClient;
import dev.blod.client.event.Render2DEvent;
import dev.blod.client.event.Subscribe;
import dev.blod.client.gui.RenderUtil;
import dev.blod.client.gui.Theme;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.BoolSetting;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;

/** "Blod Client" badge in the top-left corner with optional FPS / ping. */
public final class WatermarkModule extends Module {
    private final BoolSetting fps = add(new BoolSetting("Show FPS", true));
    private final BoolSetting ping = add(new BoolSetting("Show Ping", true));

    public WatermarkModule() {
        super("Watermark", "Draws the Blod Client watermark.", Category.CLIENT, -1);
        setListed(false);
    }

    @Subscribe
    public void onRender2D(Render2DEvent e) {
        DrawContext ctx = e.context();
        TextRenderer tr = mc.textRenderer;

        String info = "";
        if (fps.get()) info += "  |  " + mc.getCurrentFps() + " FPS";
        if (ping.get() && mc.player != null && mc.getNetworkHandler() != null) {
            PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (entry != null) info += "  |  " + entry.getLatency() + "ms";
        }

        String blod = "Blod", client = " Client";
        int w = RenderUtil.width(tr, blod) + RenderUtil.width(tr, client) + RenderUtil.width(tr, info) + 12;
        int x = 6, y = 6, h = 16;

        RenderUtil.roundedOutline(ctx, x, y, w, h, 4, Theme.alpha(Theme.DARK_RED, 200), Theme.alpha(Theme.BG, 215));
        ctx.fill(x + 4, y, x + w - 4, y + 1, Theme.RED);

        int tx = x + 6, ty = y + 4;
        RenderUtil.text(ctx, tr, blod, tx, ty, Theme.RED, true);
        tx += RenderUtil.width(tr, blod);
        RenderUtil.text(ctx, tr, client, tx, ty, 0xFFFFFFFF, true);
        tx += RenderUtil.width(tr, client);
        RenderUtil.text(ctx, tr, info, tx, ty, Theme.TEXT_DIM, true);
    }
}
