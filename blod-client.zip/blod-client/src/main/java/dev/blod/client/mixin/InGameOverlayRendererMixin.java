package dev.blod.client.mixin;

import dev.blod.client.BlodClient;
import dev.blod.client.module.impl.NoRender;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** NoRender: fire / underwater / in-wall screen overlays. */
@Mixin(InGameOverlayRenderer.class)
public abstract class InGameOverlayRendererMixin {
    @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private static void blod$fire(CallbackInfo ci) {
        NoRender n = BlodClient.module(NoRender.class);
        if (n != null && n.isEnabled() && n.fire.get()) ci.cancel();
    }

    @Inject(method = "renderUnderwaterOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private static void blod$water(CallbackInfo ci) {
        NoRender n = BlodClient.module(NoRender.class);
        if (n != null && n.isEnabled() && n.water.get()) ci.cancel();
    }

    @Inject(method = "renderInWallOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private static void blod$wall(CallbackInfo ci) {
        NoRender n = BlodClient.module(NoRender.class);
        if (n != null && n.isEnabled() && n.wall.get()) ci.cancel();
    }
}
