package dev.blod.client.event;

/** Raw mouse button event while no screen is open. action: 0 = release, 1 = press. */
public record MouseButtonEvent(int button, int action) {}
