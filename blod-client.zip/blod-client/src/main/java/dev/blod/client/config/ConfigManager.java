package dev.blod.client.config;

import com.google.gson.*;
import dev.blod.client.BlodClient;
import dev.blod.client.gui.NotificationManager;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.*;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * Saves / loads every module (enabled state, keybind, all settings) as JSON.
 * Files live in .minecraft/blodclient/configs/. The "default" profile is loaded on start and saved on exit.
 */
public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private ConfigManager() {}

    private static Path dir() {
        return FabricLoader.getInstance().getGameDir().resolve("blodclient").resolve("configs");
    }

    private static Path file(String name) {
        return dir().resolve(name.replaceAll("[^a-zA-Z0-9_\\-]", "_") + ".json");
    }

    public static boolean exists(String name) { return Files.exists(file(name)); }

    public static boolean save(String name) {
        JsonObject root = new JsonObject();
        for (Module m : BlodClient.modules().all()) {
            JsonObject mo = new JsonObject();
            if (m.isToggleable() && m.persistEnabled()) mo.addProperty("enabled", m.isEnabled());
            mo.addProperty("key", m.getKey());
            JsonObject so = new JsonObject();
            for (Setting<?> s : m.getSettings()) {
                if (s instanceof BoolSetting b) so.addProperty(s.getName(), b.get());
                else if (s instanceof NumberSetting n) so.addProperty(s.getName(), n.get());
                else if (s instanceof ModeSetting ms) so.addProperty(s.getName(), ms.getValue());
            }
            mo.add("settings", so);
            root.add(m.getName(), mo);
        }
        try {
            Files.createDirectories(dir());
            Files.writeString(file(name), GSON.toJson(root));
            return true;
        } catch (IOException e) {
            BlodClient.LOGGER.error("Could not save config {}", name, e);
            return false;
        }
    }

    public static boolean load(String name) {
        if (!exists(name)) return false;
        NotificationManager.silent = true;
        try {
            JsonObject root = JsonParser.parseString(Files.readString(file(name))).getAsJsonObject();
            for (Module m : BlodClient.modules().all()) {
                if (!root.has(m.getName())) continue;
                JsonObject mo = root.getAsJsonObject(m.getName());
                if (mo.has("key")) m.setKey(mo.get("key").getAsInt());
                if (mo.has("settings")) {
                    JsonObject so = mo.getAsJsonObject("settings");
                    for (Setting<?> s : m.getSettings()) {
                        if (!so.has(s.getName())) continue;
                        JsonElement el = so.get(s.getName());
                        if (s instanceof BoolSetting b) b.setValue(el.getAsBoolean());
                        else if (s instanceof NumberSetting n) n.setValue(el.getAsDouble());
                        else if (s instanceof ModeSetting ms) ms.setValue(el.getAsString());
                    }
                }
                if (mo.has("enabled") && m.isToggleable() && m.persistEnabled()) m.setEnabled(mo.get("enabled").getAsBoolean());
            }
            return true;
        } catch (Exception e) {
            BlodClient.LOGGER.error("Could not load config {}", name, e);
            return false;
        } finally {
            NotificationManager.silent = false;
        }
    }

    public static boolean delete(String name) {
        try { return Files.deleteIfExists(file(name)); } catch (IOException e) { return false; }
    }

    public static List<String> list() {
        List<String> out = new ArrayList<>();
        try (Stream<Path> s = Files.exists(dir()) ? Files.list(dir()) : Stream.empty()) {
            s.map(p -> p.getFileName().toString()).filter(n -> n.endsWith(".json"))
                    .forEach(n -> out.add(n.substring(0, n.length() - 5)));
        } catch (IOException ignored) {}
        return out;
    }
}
