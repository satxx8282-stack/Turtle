package dev.blod.client.module.impl;

import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import net.minecraft.util.Identifier;

/** Gives your own player the Blod cape (client-side only; other players cannot see it). See AbstractClientPlayerEntityMixin. */
public final class CapeModule extends Module {
    public static final Identifier TEXTURE = Identifier.of("blodclient", "textures/cape/blod.png");

    public CapeModule() {
        super("Cape", "Wear the Blod cape (visible to you).", Category.CLIENT, -1);
    }
}
