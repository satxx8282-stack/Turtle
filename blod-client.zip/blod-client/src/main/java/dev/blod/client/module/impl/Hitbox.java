package dev.blod.client.module.impl;

import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.BoolSetting;
import dev.blod.client.module.setting.NumberSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

/** Makes other entities easier to hit by enlarging their targeting box (EntityMixin). */
public final class Hitbox extends Module {
    private final NumberSetting expand = add(new NumberSetting("Expand", 0.2, 0.0, 1.0, 0.05));
    private final BoolSetting playersOnly = add(new BoolSetting("Players Only", true));

    public Hitbox() {
        super("Hitbox", "Bigger target boxes.", Category.COMBAT, -1);
    }

    public float expandFor(Entity e) {
        if (e == mc.player) return 0f;
        if (playersOnly.get() && !(e instanceof PlayerEntity)) return 0f;
        return (float) expand.get();
    }
}
