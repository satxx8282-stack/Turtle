package dev.blod.client.event;

/** Base class for events that can be cancelled by a listener. */
public abstract class Event {
    private boolean cancelled;
    public void cancel() { cancelled = true; }
    public boolean isCancelled() { return cancelled; }
}
