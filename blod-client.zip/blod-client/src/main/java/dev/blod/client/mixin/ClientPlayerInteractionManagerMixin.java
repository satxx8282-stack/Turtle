package dev.blod.client.mixin;

import dev.blod.client.BlodClient;
import dev.blod.client.module.impl.Criticals;
import dev.blod.client.util.CombatTracker;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Hook for every attack: remembers the target (TargetHud/TargetESP) and applies Criticals. */
@Mixin(ClientPlayerInteractionManager.class)
public abstract class ClientPlayerInteractionManagerMixin {
    @Inject(method = "attackEntity", at = @At("HEAD"))
    private void blod$attack(PlayerEntity player, Entity target, CallbackInfo ci) {
        CombatTracker.onAttack(target);
        Criticals crit = BlodClient.module(Criticals.class);
        if (crit != null && crit.isEnabled()) crit.onAttack(target);
    }
}
