package dev.blod.client.mixin;

import dev.blod.client.BlodClient;
import dev.blod.client.module.impl.FreeCam;
import dev.blod.client.module.impl.FreeLook;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.BlockView;
import net.minecraft.world.RaycastContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Overrides the final camera transform after vanilla has computed it.
 * FreeCam: position + rotation fully owned by the module.
 * FreeLook: orbits the player at the module's yaw/pitch (with block clipping).
 * Both force third-person so the player model stays visible.
 */
@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow protected abstract void setPos(double x, double y, double z);
    @Shadow protected abstract void setRotation(float yaw, float pitch);
    @Shadow private boolean thirdPerson;

    @Inject(method = "update", at = @At("TAIL"))
    private void blod$update(BlockView area, Entity focusedEntity, boolean thirdPerson, boolean inverseView,
                             float tickDelta, CallbackInfo ci) {
        FreeCam fc = BlodClient.module(FreeCam.class);
        if (fc != null && fc.isEnabled()) {
            Vec3d p = fc.getCameraPos(tickDelta);
            setRotation(fc.getYaw(), fc.getPitch());
            setPos(p.x, p.y, p.z);
            this.thirdPerson = true;
            return;
        }

        FreeLook fl = BlodClient.module(FreeLook.class);
        if (fl != null && fl.isEnabled() && focusedEntity != null) {
            setRotation(fl.getYaw(), fl.getPitch());

            Vec3d eye = focusedEntity.getCameraPosVec(tickDelta);
            Vec3d dir = Vec3d.fromPolar(fl.getPitch(), fl.getYaw());
            double dist = fl.distance.get();
            Vec3d target = eye.subtract(dir.multiply(dist));

            // don't let the camera clip into walls
            var hit = area.raycast(new RaycastContext(eye, target, RaycastContext.ShapeType.VISUAL,
                    RaycastContext.FluidHandling.NONE, focusedEntity));
            if (hit.getType() != HitResult.Type.MISS) target = hit.getPos().add(dir.multiply(0.25));

            setPos(target.x, target.y, target.z);
            this.thirdPerson = true;
        }
    }
}
