package dev.blod.client.event;

import net.minecraft.client.gui.DrawContext;

/** Fired every frame while the in-game HUD is drawn. */
public record Render2DEvent(DrawContext context, float tickDelta) {}
